# AI Resume Analyzer — Ready Bundle

Fast local tool to check resume–JD fit, ATS keyword overlap, and optional LLM rewrite via Groq.

## 1) Quickstart

```bash
# 1. Create and activate venv
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
# source .venv/bin/activate

# 2. Install deps
pip install -r requirements.txt

# 3. Configure API key (optional)
copy .env.example .env   # or manually create .env
# set GROQ_API_KEY in .env

# 4. Run
streamlit run main.py
```

Open the local URL in your browser. Upload a PDF resume and paste a job description.

## 2) Sample Data

- `sample_data/sample_resume.pdf` — minimal example PDF
- `sample_data/job_description.txt` — example JD text

Use these to test the app without your own files.

## 3) Features

- Semantic similarity using SentenceTransformer `all-MiniLM-L6-v2`
- ATS keyword overlap with matched and missing terms
- Non‑LLM improvement tips always available
- Optional LLM rewrite using Groq if `GROQ_API_KEY` is set

## 4) Project Structure

```
AI-Resume-Analyzer-Project-Ready/
├─ main.py
├─ ats_score.py
├─ resume_ai.py
├─ utils.py
├─ requirements.txt
├─ .env.example
├─ .gitignore
├─ sample_data/
│  ├─ sample_resume.pdf
│  └─ job_description.txt
├─ tests/
│  └─ test_basic.py
├─ .github/workflows/ci.yml
├─ Dockerfile
└─ Makefile
```

## 5) Docker (optional)

```bash
docker build -t resume-analyzer .
docker run --rm -p 8501:8501 resume-analyzer
```

Then open http://localhost:8501

## 6) CI (optional)

A simple GitHub Actions workflow runs `pip install` and a smoke test.

## 7) Notes

- Keep `.env` out of Git. The `.gitignore` already excludes it.
- Do not upload sensitive resumes. This is a local tool.